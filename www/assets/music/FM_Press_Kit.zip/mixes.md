# FM Mixes

## SKFF b2b FM | Proper Techno DJ Mix

- url: https://www.youtube.com/watch?v=8WGoxI1bvI8
- genre: Techno
- date: 22.04.2025
- duration: 3h 03min

## 12"/h | Czwórka Polskie Radio

- url: https://www.youtube.com/watch?v=i8qnjaO5ioU
- genre: Electro
- date: 11.04.2024
- duration: 50min

## SKFF b2b FM | Techno vinyl set

- url: https://www.youtube.com/watch?v=zTmuI3wd87I
- genre: Techno
- date: 24.02.2024
- duration: 2h 09min

## NfSoP podcast #28 | Neurofunk Society of Poland

- url: https://www.youtube.com/watch?v=06RXqcR_tns
- genre: Drum and bass
- date: 10.2016
- duration: 1h 02min

## UDS podcast #12 | Underground Session

- url: https://www.mixcloud.com/fmmaciej/uds-podcast-vol-12/
- date: 12.2014
- duration: 1h 18min
- genre: Drum and bass
