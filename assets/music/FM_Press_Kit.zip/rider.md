# FM Rider

## Technical

- 2 × Technics SL-1200/1210 turntables in excellent condition
- High-quality DJ mixer
- Optional: Pioneer CDJ / XDJ-1000 mk2
- Stable and solid booth table - must minimize vibrations
- Preferred: concrete slab under each turntable for stability
- Needles and slipmats: I bring my own

## Monitoring

- I primarily play on headphones
- Booth monitors are not required

## Hospitality

- Still or sparkling mineral water, sufficient supply for the duration of the performance
- No alcohol or additional hospitality requirements
